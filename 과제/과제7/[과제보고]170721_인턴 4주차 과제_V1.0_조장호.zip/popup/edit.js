function btnClose()
{
    window.opener.top.location.href = "../category.html";
    window.close();
}