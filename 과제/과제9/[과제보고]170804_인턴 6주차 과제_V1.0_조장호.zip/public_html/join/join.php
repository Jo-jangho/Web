<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-08-01
 * Time: 오전 10:03
 */

include_once '../Class/CDBControl.php';

$id = $_POST['ID'];
$pw = $_POST['PW'];
$nick_name = $_POST['nick_name'];
$birth = $_POST['birth'];

$db = new CDBControl();
$query = "INSERT INTO user (`id`, `password`, `nick_name`, `birth`) VALUES ('" . $id . "', password('" . $pw . "'), '" . $nick_name . "', " . $birth . ")";
$db->setQuery($query);
$db = null;

?>
<script type="text/javascript" src="../common-js/common.js"></script>
<script>setUrl('../index.php')</script>