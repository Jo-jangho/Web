<?php

include_once "../common/header.php";

?>

<form action="join.php" method="post" name="form" id="form" onsubmit="return check()">
    <table>
        <tr>
            <td><label for="ID">ID</label></td>
            <td><input type="text" name="ID" id="ID"></td>
        </tr>
        <tr>
            <td><label for="PW">PW</label></td>
            <td><input type="password" name="PW" id="PW"></td>
        </tr>
        <tr>
            <td><label for="nick_name">닉네임</label></td>
            <td><input type="text" name="nick_name" id="nick_name"></td>
        </tr>
        <tr>
            <td><label for="birth">생일</label></td>
            <td><input type="text" name="birth" id="birth"></td>
        </tr>
        <tr>
            <td colspan="2"><input type="submit" value="회원가입"> </td>
        </tr>
    </table>
</form>

<?php
include_once "../common/footer.html";
?>