<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-08-01
 * Time: 오후 4:44
 */

include_once "../Class/CDBControl.php";

session_start();

$id = $_POST['ID'];
$pw = $_POST['PW'];

if($id && $pw)
{
    try
    {
        login($id, $pw);
        $_SESSION['login_user'] = $id;
        ?>
        <script type="text/javascript" src="../common-js/common.js"></script>
        <script>setUrl('../index.php')</script>
<?php
    }
    catch(Exception $e)
    {
        echo "catch<br>" . $e;
        exit;
    }
}
else
{
    ?>
    <script>alert("가입 정보를 확인해 주세요!"); history.back();</script>
<?php
}

function login($_id, $_pw)
{
    $db = new CDBControl();
    $query = "SELECT * FROM user WHERE id='" . $_id . "' AND password=password('" . $_pw . "' )";
    $result = $db->getQuery($query);


    if ($result != 0)
    {
        $_SESSION['nick_name'] = $result['nick_name'];
        $db = null;
    }
    else
    {
        ?>
        <script>alert("가입 정보를 확인해 주세요!"); history.back();</script>
        <?php
        exit;
    }
}
?>