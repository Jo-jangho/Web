<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-08-02
 * Time: 오전 10:27
 */

session_start();
unset($_SESSION["login_user"]);
session_destroy();

?>
<script type="text/javascript" src="../common-js/common.js"></script>
<script>setUrl('../index.php')</script>