<?php
include_once "common/header.php";
include_once "Class/CDBControl.php";
?>
    <h3>자유게시판</h3>

    <div>
        <a href="/board/boardWritingForm.php">글쓰기</a>
    </div>

    <table>
        <thead>
            <tr>
                <th class="no">번호</th>
                <th class="title">제목</th>
                <th class="author">작성자</th>
                <th class="date">작성일</th>
                <th class="hit">조회</th>
            </tr>
        </thead>
        <tbody>
        <?php
            include_once "board/boardList.php";
        ?>
        </tbody>
    </table>

    <!--<div class="paging">
        <?php /*echo $paging */?>
    </div>-->

    <form action="board/searchList.php" method="post">
        <select name="search" id="search">
            <option value="title">제목</option>
            <option value="nick_name">작성자</option>
        </select>
        <input type="text" name="searchValue">
        <input type="submit" value="검색">
    </form>

<?php
include_once "common/footer.html";
?>
