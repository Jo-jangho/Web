<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="../common-css/common.css">
    <script type="text/javascript" src="../common-js/common.js"></script>
</head>
<body>
<div class="container">
    <h1>조장호 개인 게시판</h1>
    <div class="btnWrap">
        <?php
            session_start();

            if(isset($_SESSION['login_user']))
            {
                echo $_SESSION['nick_name'] . "님 안녕하세요";
                echo '<button onclick=setUrl("../index.php")>홈</button>';
                echo '<button onclick=setUrl("../user/logout.php")>로그아웃</button>';
            }
            else
            {
                echo '<button onclick=setUrl("../index.php")>홈</button>';
                echo '<button onclick=setUrl("../join/joinForm.php")>회원가입</button>';
                echo '<button onclick=setUrl("../user/loginForm.php")>로그인</button>';
            }

        ?>
    </div>
    <hr>