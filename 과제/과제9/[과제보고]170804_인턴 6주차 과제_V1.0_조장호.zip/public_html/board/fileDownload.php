<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-08-04
 * Time: 오후 1:05
 */

$file_name = $_REQUEST["file_name"];
$downloadDir = 'C:\AutoSet9\public_html\file\\';
$downloadFile = $downloadDir . $file_name;

if(file_exists($downloadFile))
{
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename=' . basename($downloadFile));
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($downloadFile));
    ob_clean();
    flush();
    readfile($downloadFile);
}
else
{
    ?>
    <script type="text/javascript">
        alert("파일이 존재 하지 않습니다. \r\n 관리자에게 문의해주세요.");
        history.back();
    </script>
    <?
}

?>