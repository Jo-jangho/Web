<script type="text/javascript" src="../common-js/common.js"></script>
<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-08-04
 * Time: 오후 3:04
 */

include_once "../Class/CDBControl.php";

if(isset($_POST['search']))
{
    $search = $_POST['search'];
    $searchValue = $_POST['searchValue'];
    $where = null;

    if($search != null)
    {
        $where = "where $search like '%$searchValue%'";
    }

    $db = new CDBControl();
    $query = 'select * from board ' . $where . 'ORDER BY posting_num DESC';
    $db = null;
}
?>

<form action="../index.php" method="post" name="queryForm">
    <input type="hidden" name="query" value="<?=$query?>">
</form>
<script>
    document.queryForm.submit();
</script>
