
<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-08-04
 * Time: 오전 10:17
 */

$db = new CDBControl();
if(isset($_POST['query']))
{
    $query = $_POST['query'];
}
else
{
    $query = "SELECT * FROM board ORDER BY posting_num DESC";// . $sqlLimit;
}
$result = $db->getRowQuery($query);

while($row = $result->fetch_assoc())
{
    ?>
    <tr>
        <td><?=$row['posting_num']?></td>
        <td><a href="../board/boardContentForm.php?index=<?=$row['posting_num']?>"> <?=$row['title']?></a></td>
        <td><?=$row['nick_name']?></td>
        <td><?=$row['date']?></td>
        <td><?=$row['tic']?></td>
    </tr>
    <?php
}

$db = null;
?>


