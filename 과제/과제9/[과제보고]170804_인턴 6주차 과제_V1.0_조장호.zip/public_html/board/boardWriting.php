<?php

include_once "../Class/CDBControl.php";
echo '<script type="text/javascript" src="../common-js/common.js"></script>';

session_start();

$index = null;
if(isset($_SESSION['login_user']))
{
    $index = $_GET['index'];
    $title = $_POST['title'];
    $nick_name = $_SESSION['nick_name'];
    $date = time();
    $content = $_POST['content'];
    $file_name = null;
    if($_FILES['file_name'])
    {
        $file_name = basename($_FILES['file_name']['name']);
        $uploadDir = 'C:\AutoSet9\public_html\file\\';

        $uploadFile = $uploadDir . $file_name;

        if (move_uploaded_file($_FILES['file_name']['tmp_name'], $uploadFile))
        {
            echo "파일이 유효하고, 성공적으로 업로드 되었습니다.\n";
        }
        else
        {
            print "파일 업로드 공격의 가능성이 있습니다!\n";
        }
    }

    if(isset($_POST['reg']))
    {
        $db = new CDBControl();
        $query = "INSERT INTO board (`title`, `nick_name`, `content`, `file_name`) VALUES ('" . $title . "', '" . $nick_name . "', '" . $content . "', '" . $file_name . "')";
        $db->setQuery($query);
        $db = null;
        echo '<script>setUrl("../index.php");</script>';
    }
    else if(isset($_POST['edit']))
    {
        $db = new CDBControl();
        $query = "UPDATE `board` SET `title`='" . $title . "', `date`=current_time(), `content`='" . $content . "', `file_name`='" . $file_name . "' where posting_num=" . $index;
        $db->setQuery($query);
        $db = null;
        echo "<script>updateItem($index);</script>";
    }
}
else
{
    echo '<script>setUrl("../user/loginForm.php");</script>';
}

?>