<?php

include_once "../common/header.php";
include_once "../Class/CDBControl.php";
echo '<link rel="stylesheet" href="css/boardContentForm.css">';
echo '<script type="text/javascript" src="js/boardContentForm.js"></script>';

$index = $_GET['index'];

$db = new CDBControl();
$db->setTic($index);
$query = 'SELECT * FROM board WHERE posting_num=' . $index;
$row = $db->getQuery($query);
?>

    <table>
        <thead>
        <tr>
            <th class="no">번호</th>
            <th class="title">제목</th>
            <th class="author">작성자</th>
            <th class="date">작성일</th>
            <th class="hit">조회</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td><?= $row['posting_num'] ?></td>
            <td><?= $row['title'] ?></td>
            <td><?= $row['nick_name'] ?></td>
            <td><?= $row['date'] ?></td>
            <td><?= $row['tic'] ?></td>
        </tr>
        <tr>
            <th class="file">첨부파일</th>
            <td colspan="4"><a href="fileDownload.php?file_name=<?=$row['file_name'] ?>"> <?= $row['file_name'] ?></a></td>
        </tr>
        <tr>
            <td colspan="5"><pre class="content"><?= $row['content'] ?> </pre></td>
        </tr>
        </tbody>
    </table>
    <button onclick=setUrl("../index.php")>목록</button>
    <button onclick=updateForm(<?= '"' . $row['nick_name'] . '&index=' . $index . '"'; ?>)>수정</button>
    <button onclick=deleteItem(<?= '"' . $row['nick_name'] . '&index=' . $index . '"'; ?>)>삭제</button>

<?php
include_once "../common/footer.html";
$db = null;
?>