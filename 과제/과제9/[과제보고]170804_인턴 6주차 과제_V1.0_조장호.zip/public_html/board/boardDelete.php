<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-08-03
 * Time: 오후 12:42
 */

include_once "../Class/CDBControl.php";
echo '<script type="text/javascript" src="../common-js/common.js"></script>';

session_start();

if($_SESSION['nick_name'] == $_GET['nick_name'])
{
    $db = new CDBControl();
    $query = "DELETE FROM board WHERE posting_num=" . $_GET['index'];
    $db->setQuery($query);
    $db = null;
}
else
{
    echo '<script>alert(\'삭제 권한이 없습니다.\');</script>';
    echo '<script>history.back();</script>';
}

echo '<script>setUrl("../index.php");</script>';

?>