<?php
/**
 * Created bsuccesstorm.
 * User: Administrator
 * Date: 2017-07-31
 * Time: 오후 3:09
 */

Class CDBControl
{
    private $mysql;
    public function __construct()
    {}

    public function __destruct()
    {
        $this->mysql = null;
    }

    public function connect($db_name)
    {
        $this->mysql = mysqli_connect('127.0.0.1', 'root', 'autoset');
        if(!$this->mysql)
        {
            throw new Exception('Could not connect to database server');
        }

        mysqli_select_db($this->mysql, $db_name);

        $this->mysql->autocommit(false);

        return $this->mysql;
    }

    public function setQuery($query)
    {
        try
        {
            $this->mysql = $this->connect('board_db');

            /**/
            $result = $this->mysql->query($query);

            $this->mysql->commit();
            $this->mysql->close();
        }
        catch (Exception $e)
        {
            $this->mysql->rollback();
        }
    }

    public function getQuery($query)
    {
        try
        {
            /**/
            $this->mysql = $this->connect('board_db');

            $result = $this->mysql->query($query);
            $row = $result->fetch_assoc();

            $this->mysql->commit();
            $this->mysql->close();

            return $row;
        }
        catch (Exception $e)
        {
            $this->mysql->rollback();
        }
    }



    public function getRowQuery($query)
    {
        try
        {
            /**/
            $this->mysql = $this->connect('board_db');

            $result = $this->mysql->query($query);

            $this->mysql->commit();
            $this->mysql->close();

            return $result;
        }
        catch (Exception $e)
        {
            $this->mysql->rollback();
        }
    }

    public function setTic($index)
    {
        try
        {
            /**/
            $this->mysql = $this->connect('board_db');

            $query = 'UPDATE board SET tic = tic + 1 WHERE posting_num=' . $index;
            $result = $this->mysql->query($query);

            $this->mysql->commit();
            $this->mysql->close();
        }
        catch (Exception $e)
        {
            $this->mysql->rollback();
        }
    }
}